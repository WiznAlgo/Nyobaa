'use client';

import { useMemo } from 'react';
import { MessageCircleHeart, Send } from 'lucide-react';
import { buildWhatsAppLink } from '@/lib/utils';
import { siteConfig } from '@/data/site-config';

type ResponseFormProps = {
  title: string;
  description: string;
  buttonLabel: string;
};

export function ResponseForm({ title, description, buttonLabel }: ResponseFormProps) {
  const whatsappLink = useMemo(() => {
    return buildWhatsAppLink(siteConfig.whatsappNumber, siteConfig.whatsappText);
  }, []);

  return (
    <div className="space-y-5 text-left">
      <div className="text-center">
        <div className="icon-badge mx-auto mb-3">
          <MessageCircleHeart size={20} />
        </div>
        <h2 className="romantic-text text-2xl font-semibold text-amber-950 sm:text-3xl">{title}</h2>
        <p className="mx-auto mt-4 max-w-xl text-sm leading-7 text-amber-950/72 sm:text-base">
          {description}
        </p>
      </div>

      <div className="rounded-[26px] border border-amber-200/60 bg-white/70 p-5 text-center shadow-[0_10px_24px_rgba(128,94,50,0.05)] sm:p-6">
        <p className="text-sm leading-7 text-amber-950/70 sm:text-base">
          Kalau kamu mau balas, cukup pencet tombol di bawah ini yaa. Nggak perlu ngetik di website, langsung ke WhatsApp aja 🤍
        </p>

        <a href={whatsappLink} target="_blank" rel="noreferrer" className="wa-button mt-5 w-full sm:w-auto">
          <Send size={16} />
          {buttonLabel}
        </a>
      </div>
    </div>
  );
}
