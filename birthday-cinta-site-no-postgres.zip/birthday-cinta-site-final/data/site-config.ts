export const siteConfig = {
  gateOnePassword: '16042009',
  gateTwoPassword: '07012009',
  whatsappNumber: '6282233412942',
  whatsappText: 'aku udah lihat website-nya 😆🌻'
} as const;
