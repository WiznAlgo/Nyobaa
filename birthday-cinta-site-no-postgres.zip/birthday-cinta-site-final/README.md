# Birthday Cinta Site

Versi ini sudah **tanpa Postgres** dan **tanpa environment variable wajib**.

## Jalankan lokal

```bash
npm install
npm run dev
```

## Deploy ke Vercel

1. Upload project ke GitHub
2. Import repo ke Vercel
3. Deploy

Selesai. Tidak perlu mengisi `POSTGRES_URL`.

## Data yang sudah ditanam di code

- Password Gate 1: `16042009`
- Password Gate 2: `07012009`
- WhatsApp: `6282233412942`

Lokasi config:
- `data/site-config.ts`
