import { NextResponse } from 'next/server';
import { normalizePassword } from '@/lib/utils';
import { siteConfig } from '@/data/site-config';

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      gate?: 'main' | 'secret';
      password?: string;
    };

    if (!body.gate || !body.password) {
      return NextResponse.json({ ok: false, message: 'Data belum lengkap.' }, { status: 400 });
    }

    const expected = body.gate === 'secret' ? siteConfig.gateTwoPassword : siteConfig.gateOnePassword;
    const isMatch = normalizePassword(body.password) === normalizePassword(expected);

    return NextResponse.json({
      ok: isMatch,
      message: isMatch ? 'access granted' : 'masih belum pas... coba inget satu tanggal lain 😆'
    });
  } catch {
    return NextResponse.json(
      {
        ok: false,
        message: 'Terjadi kesalahan saat mengecek password.'
      },
      { status: 500 }
    );
  }
}
